"""ctbridge - generic Python <-> browser bridge for the JupyterLite games.

A game is a plain Python object (see ``BridgeWidget``) that receives browser events and answers with
DOM specs / DOM patches / Canvas 2D ops. The only JavaScript is ``assets/bridge.js``.
"""

from .canvas import Canvas2D, FrameBuffer
from .dom import el

__all__ = ["BridgeWidget", "Canvas2D", "FrameBuffer", "el"]
__version__ = "0.1.1"


def __getattr__(name):          # anywidget is only needed in the browser kernel, not for headless tests
    if name == "BridgeWidget":
        from .widget import BridgeWidget
        return BridgeWidget
    raise AttributeError(name)
