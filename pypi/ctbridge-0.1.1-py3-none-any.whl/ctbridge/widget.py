"""anywidget glue: forwards messages between ``assets/bridge.js`` and a game ``app``.

The app needs ``on_event(msg: dict)``; it is created with ``app_factory(send)`` where
``send(message: dict, data: bytes | None = None)`` posts a message (plus one binary buffer) to the browser.

Python -> JS: ``{t:"ui", spec, prevent?, css?}`` | ``{t:"frame", patches, draw}`` (+ Float32 buffer) | ``{t:"fullscreen", on}``
JS -> Python: ``{ev:"ready"}``, ``{ev:"tick", dt, sizes}``, ``{ev:"key", ...}``, ``{ev:"fullscreen", on}``,
and DOM events ``{ev, id, value?, checked?, x?, y?, rect?}`` for nodes that declare ``on=[...]``.
"""

from __future__ import annotations

from pathlib import Path

import anywidget

_ASSETS = Path(__file__).parent / "assets"


class BridgeWidget(anywidget.AnyWidget):
    _esm = _ASSETS / "bridge.js"

    def __init__(self, app_factory):
        super().__init__()
        self.app = app_factory(self._to_browser)
        self.on_msg(self._on_msg)

    def _to_browser(self, content, data=None):
        self.send(content, [data] if data else None)

    def _on_msg(self, _widget, content, _buffers):
        try:
            self.app.on_event(content)
        except Exception:                      # never stall the frame loop silently
            import traceback
            traceback.print_exc()
            self._to_browser({"t": "frame", "patches": [], "draw": {}})
