// Generic browser bridge for ctairplane. It contains NO game logic: it builds DOM from a
// declarative spec sent by Python, replays Canvas 2D ops sent by Python, requests animation
// frames, and forwards DOM events back to Python.
//
// Python -> JS messages (model.send):
//   {t:"ui", spec, prevent:[codes], css:"..."}            build the DOM (answer to "ready"); css is optional
//   {t:"frame", patches:[...], draw:{canvasId:[ops]}}      + one Float32 buffer with all path points
//   {t:"fullscreen", on:true|false|"toggle"}
// JS -> Python messages:
//   {ev:"ready"}  {ev:"tick", dt, sizes:{id:[w,h]}}  {ev:"key", ...}  {ev:"fullscreen", on}
//   {ev:<dom event>, id, value?, checked?, x?, y?, rect?}
export default {
  render({ model, el }) {
    const root = document.createElement("div");
    root.className = "cp";
    root.tabIndex = 0;
    el.appendChild(root);

    const nodes = new Map(), canvases = new Map();
    let prevent = new Set(), waiting = false, sentAt = 0, last = performance.now(), alive = true, built = false;
    const send = m => model.send(m);

    function build(n) {
      if (typeof n === "string") return document.createTextNode(n);
      const e = document.createElement(n.tag);
      if (n.cls) e.className = n.cls;
      if (n.text != null) e.textContent = n.text;
      for (const [k, v] of Object.entries(n.attrs || {})) e.setAttribute(k, v);
      for (const [k, v] of Object.entries(n.style || {})) e.style[k] = v;
      if (n.value != null) e.value = n.value;
      if (n.checked != null) e.checked = n.checked;
      if (n.id) {
        nodes.set(n.id, e);
        if (n.tag === "canvas") canvases.set(n.id, { cv: e, ctx: e.getContext("2d") });
      }
      if (n.focus) e.addEventListener("pointerdown", () => root.focus());
      for (const type of n.on || []) {
        e.addEventListener(type, ev => {
          const m = { ev: type, id: n.id };
          if ("value" in e) m.value = e.value;
          if (e.type === "checkbox") m.checked = e.checked;
          if (ev.clientX !== undefined) {
            const r = e.getBoundingClientRect();
            m.x = ev.clientX; m.y = ev.clientY; m.rect = [r.left, r.top, r.width, r.height];
          }
          if (type === "pointerdown" && n.capture) e.setPointerCapture(ev.pointerId);
          send(m);
        });
      }
      for (const c of n.children || []) e.appendChild(build(c));
      return e;
    }

    function patch([op, id, a, b]) {
      const e = nodes.get(id);
      if (!e) return;
      if (op === "text") e.textContent = a;
      else if (op === "cls") e.classList.toggle(a, !!b);
      else if (op === "val") e.value = a;
      else if (op === "checked") e.checked = !!a;
      else if (op === "attr") e.setAttribute(a, b);
      else if (op === "style") e.style[a] = b;
      else if (op === "children") e.replaceChildren(...a.map(build));
    }

    function exec(ctx, ops, f32) {
      for (const op of ops) {
        const k = op[0];
        if (k === "set") {
          let v = op[2];
          if (v && v.lin) {
            const [x0, y0, x1, y1, stops] = v.lin, g = ctx.createLinearGradient(x0, y0, x1, y1);
            for (const [o, c] of stops) g.addColorStop(o, c);
            v = g;
          }
          ctx[op[1]] = v;
        } else if (k === "path") {
          const [, off, n] = op;
          ctx.moveTo(f32[off], f32[off + 1]);                       // off = index into the float buffer
          for (let i = 1; i < n; i++) ctx.lineTo(f32[off + 2 * i], f32[off + 2 * i + 1]);
        } else ctx[k](...op.slice(1));
      }
    }

    function draw(msg, buffers) {
      let f32 = new Float32Array(0);
      if (buffers && buffers[0]) {
        const b = buffers[0];
        f32 = b.byteOffset % 4 === 0 ? new Float32Array(b.buffer, b.byteOffset, b.byteLength >> 2)
                                     : new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
      }
      for (const p of msg.patches || []) patch(p);
      const dpr = window.devicePixelRatio || 1;
      for (const [id, ops] of Object.entries(msg.draw || {})) {
        const c = canvases.get(id);
        if (!c) continue;
        const w = Math.round(c.cv.clientWidth * dpr), h = Math.round(c.cv.clientHeight * dpr);
        if (c.cv.width !== w || c.cv.height !== h) { c.cv.width = w; c.cv.height = h; }
        c.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        exec(c.ctx, ops, f32);
      }
    }

    model.on("msg:custom", (msg, buffers) => {
      if (msg.t === "ui") {
        nodes.clear(); canvases.clear(); nodes.set("__root", root);
        root.replaceChildren(build(msg.spec));
        if (msg.css) { const st = document.createElement("style"); st.textContent = msg.css; root.prepend(st); }
        prevent = new Set(msg.prevent || []); built = true; waiting = false;
      } else if (msg.t === "frame") { draw(msg, buffers); waiting = false; }
      else if (msg.t === "fullscreen") {
        const on = msg.on === "toggle" ? document.fullscreenElement !== root : !!msg.on;
        if (on) (root.requestFullscreen || root.webkitRequestFullscreen).call(root).catch(() => {});
        else if (document.fullscreenElement) document.exitFullscreen();
      }
    });

    root.addEventListener("keydown", e => {
      const t = e.target, inp = t.tagName === "INPUT" && (t.type === "number" || t.type === "range");
      if (!inp && (prevent.has(e.code) || prevent.has(e.key))) e.preventDefault();
      send({ ev: "key", key: e.key, code: e.code, inp });
    });
    const onFs = () => send({ ev: "fullscreen", on: document.fullscreenElement === root });
    document.addEventListener("fullscreenchange", onFs);

    // Only tick while the widget is on screen: several widgets can share one kernel.
    let visible = true;
    const io = typeof IntersectionObserver === "function" ? new IntersectionObserver(es => { visible = es[es.length - 1].isIntersecting; }) : null;
    if (io) io.observe(root);

    function tick(now) {
      if (!alive) return;
      if (waiting && now - sentAt > 2000) waiting = false;      // lost reply: don't stall forever
      if (built && !waiting && visible) {
        waiting = true; sentAt = now;
        const sizes = {};
        for (const [id, c] of canvases) sizes[id] = [c.cv.clientWidth, c.cv.clientHeight];
        send({ ev: "tick", dt: (now - last) / 1000, sizes });
      }
      last = now;
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
    send({ ev: "ready" });

    return () => { alive = false; if (io) io.disconnect(); document.removeEventListener("fullscreenchange", onFs); };
  },
};
