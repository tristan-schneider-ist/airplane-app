"""Declarative DOM spec: plain dicts the JS bridge turns into elements (see assets/bridge.js)."""

from __future__ import annotations


def el(tag, *children, id=None, cls=None, text=None, on=None, attrs=None, style=None,
       value=None, checked=None, capture=False, focus=False):
    n = {"tag": tag}
    for k, v in (("id", id), ("cls", cls), ("text", text), ("on", on), ("attrs", attrs),
                 ("style", style), ("value", value), ("checked", checked)):
        if v is not None:
            n[k] = v
    if capture:
        n["capture"] = True
    if focus:
        n["focus"] = True
    if children:
        n["children"] = list(children)
    return n
