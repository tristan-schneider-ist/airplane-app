"""Recorder for Canvas 2D drawing: Python emits ops, the (generic) JS bridge replays them.

``c.beginPath()``, ``c.moveTo(x, y)``, ``c.fillRect(...)`` … are recorded under their JS names so the
drawing code reads like canvas code. Properties go through ``c.set("fillStyle", ...)``; a linear
gradient is ``{"lin": [x0, y0, x1, y1, [[offset, color], ...]]}``. Bulk polylines use ``c.path(points)``
and travel as one Float32 buffer per frame (``FrameBuffer``).
"""

from __future__ import annotations

from array import array


class FrameBuffer:
    """All coordinate arrays of one frame, concatenated into a single Float32 buffer."""

    def __init__(self):
        self.data = array("f")

    def add(self, flat):
        """Append [x0, y0, ...]; returns (float offset, number of points)."""
        off = len(self.data)
        self.data.extend(flat)
        return off, len(flat) // 2

    def to_bytes(self) -> bytes:
        return self.data.tobytes()


class Canvas2D:
    def __init__(self, buf: FrameBuffer):
        self.ops, self._buf = [], buf

    def __getattr__(self, name):          # c.fillRect(...) -> ["fillRect", ...]
        if name.startswith("_"):
            raise AttributeError(name)
        return lambda *a: self.ops.append([name, *a])

    def set(self, prop, value):
        self.ops.append(["set", prop, value])

    def path(self, flat, close=False):
        """moveTo(first point) then lineTo(...) through ``flat`` = [x0, y0, x1, y1, ...]."""
        if len(flat) >= 2:
            off, n = self._buf.add(flat)
            self.ops.append(["path", off, n])
        if close:
            self.ops.append(["closePath"])
