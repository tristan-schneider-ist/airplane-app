"""matplotlib figure of a flight (altitude with corridor, and the input u)."""

from __future__ import annotations

import numpy as np


def plot_flight(flight, task, figsize=(8.5, 4.6), dpi=90):
    """Return a ``matplotlib.figure.Figure`` (no pyplot global state, safe inside ``ipywidgets.Output``)."""
    from matplotlib.figure import Figure

    t = np.arange(len(flight.Y)) * flight.Ts
    R, Y, U = np.asarray(flight.R), np.asarray(flight.Y), np.asarray(flight.U)
    fig = Figure(figsize=figsize, dpi=dpi, layout="constrained")
    ax, au = fig.subplots(2, 1, sharex=True, height_ratios=[2.2, 1])

    #ax.fill_between(t, R - flight.tol, R + flight.tol, color="#2f6df6", alpha=0.15, lw=0, label=f"corridor ±{flight.tol:g}")
    ax.plot(t, R, "--", color="#1d4fd8", lw=1.5, label="Sollhöhe r")
    ax.plot(t, np.clip(Y, *task.y_lim) if np.all(np.isfinite(Y)) else Y, color="#e5484d", lw=2, label="Regelgröße y (Höhe)")
    ax.set_ylim(*task.y_lim)
    ax.set_ylabel("Höhe")
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right", ncol=3, fontsize=8, frameon=False)
    ax.set_title(flight.summary(emoji=False), fontsize=10, loc="left")

    au.axhline(flight.u_max, color="#f59e0b", lw=1, alpha=0.6)
    au.axhline(-flight.u_max, color="#f59e0b", lw=1, alpha=0.6)
    au.step(t, U, where="post", color="#d97706", lw=1.6)
    au.set_ylim(-flight.u_max * 1.15, flight.u_max * 1.15)
    au.set_ylabel("Stellgröße u")
    au.set_xlabel("Zeit in Sekunden")
    au.set_xlim(0, flight.duration)
    au.grid(alpha=0.3)
    return fig


def figure_html(fig) -> str:
    """The figure as a responsive inline PNG (works without an inline-matplotlib backend, e.g. in Pyodide)."""
    import base64
    import io
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    data = base64.b64encode(buf.getvalue()).decode("ascii")
    return f'<img alt="flight plots" style="max-width:100%;height:auto" src="data:image/png;base64,{data}">'
