"""ctairplane - steer an airplane (a SISO plant you define with python-control) along a reference."""

from .core.flight import Flight, simulate
from .core.plants import double_integrator
from .core.references import constant, sine, step, steps, waypoints
from .core.task import Task
from .plotting import plot_flight


def __getattr__(name):          # notebook API needs ipywidgets/anywidget: import it lazily (keeps core headless)
    if name in ("manual", "fly", "tune", "tune_pid", "tune_state_feedback"):
        from . import notebook
        return getattr(notebook, name)
    raise AttributeError(name)


__all__ = [
    "Task", "Flight", "simulate", "plot_flight", "double_integrator",
    "manual", "fly", "tune", "tune_pid", "tune_state_feedback",
    "constant", "sine", "step", "steps", "waypoints",
]
__version__ = "0.2.2"
