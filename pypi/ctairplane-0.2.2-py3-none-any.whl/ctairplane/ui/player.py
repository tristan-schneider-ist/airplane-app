"""Playback of a precomputed ``Flight``: the animated airplane with play / pause / restart / scrub."""

from __future__ import annotations

from ctbridge import el

from ..core.flight import Flight
from .base import BridgeApp, header, scene_block, speed_select
from .scene import FlightCursor
from .widgets import fmt, stat


class Player(BridgeApp):
    def __init__(self, task, send, flight: Flight | None = None):
        self.cursor, self.playing, self.acc = None, False, 0.0
        super().__init__(task, send)
        if flight is not None:
            self.load(flight)

    @property
    def view(self):
        return self.cursor

    def load(self, flight: Flight, autoplay=True):
        """Show a (new) flight from the start."""
        self.cursor = FlightCursor(flight, 0)
        self.acc, self.playing = 0.0, autoplay
        self.patch("attr", "scrub", "max", str(flight.n))
        self._refresh(True)

    # ---- layout
    def spec(self):
        n = self.cursor.flight.n if self.cursor else 1
        return el("div", header(self.task),
                  scene_block(),
                  el("div",
                     el("button", id="bPlay", text="⏸ Pause", cls="btn", on=["click"]),
                     el("button", id="bRestart", text="↺ Wiederholen", cls="btn sec", on=["click"]),
                     el("input", id="scrub", on=["input"], attrs={"type": "range", "min": "0", "max": str(n), "step": "1"},
                        value="0", style={"flex": "1 1 160px"}),
                     speed_select(),
                     el("div", stat("Zeit", "sT", "0.0 s"), stat("Abweichung e", "sE", "0.00 m"),
                        stat("Durchschnittliche Abweichung", "sMeanE"), cls="stats"),
                     cls="bar"), cls="app")

    def handlers(self):
        return {("click", "bPlay"): lambda m: self.toggle(),
                ("click", "bRestart"): lambda m: self.restart(),
                ("input", "scrub"): self._on_scrub}

    def after_ready(self):
        self._refresh(True)

    # ---- control
    def toggle(self):
        k = self.cursor
        if k.k >= k.flight.n:
            self.restart()
        else:
            self.playing = not self.playing
        self._refresh(True)

    def restart(self):
        self.cursor.k, self.acc, self.playing = 0, 0.0, True
        self._refresh(True)

    def _on_scrub(self, m):
        self.cursor.k, self.playing = max(0, min(self.cursor.flight.n, int(float(m["value"])))), False
        self._refresh(True)

    def on_key(self, m):
        if m.get("inp"):
            return
        if m["code"] == "Space":
            self.toggle()
        elif m["key"] in ("f", "F"):
            self._send({"t": "fullscreen", "on": "toggle"})

    def advance(self, dt):
        if not (self.playing and self.cursor):
            return
        self.acc += dt * self.speed
        steps = int(self.acc / self.cursor.Ts)
        self.acc -= steps * self.cursor.Ts
        self.cursor.k = min(self.cursor.flight.n, self.cursor.k + steps)
        if self.cursor.k >= self.cursor.flight.n:
            self.playing = False
        self._refresh()

    def _refresh(self, force=False):
        c = self.cursor
        if c is None:
            return
        f, k = c.flight, c.k
        self.text("bPlay", "↺ Wiederholen" if k >= f.n else "⏸ Pause" if self.playing else "▶ Los")
        self.patch("val", "scrub", str(k))
        self.update_stats(force)

    def update_stats(self, force=False):
        c = self.cursor
        if c is None or not self.throttled(force) and self.playing:
            return
        f, k = c.flight, c.k
        self.text("sT", f"{c.t:.1f} s")
        self.text("sE", fmt(f.R[k] - f.Y[k]) + " m")
        self.text("sIn", f"{f.score_at(k)} %" if k else "–")
        self.text("sMeanE", f"{f.mean_error_at(k):.3f} m" if k else "–")
