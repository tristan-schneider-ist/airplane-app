"""Game-specific widgets built from the generic DOM spec (``ctbridge.el``)."""

from __future__ import annotations

from ctbridge import el


def fmt(v: float, nd: int = 2) -> str:
    return f"{v:.{nd}f}"


def num(v: float) -> str:
    """Like JS ``+v.toFixed(6)`` -> shortest text (``2`` not ``2.0``)."""
    s = f"{round(v, 6):.6f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def vslider(umax):
    return el("div",
              el("div", el("div", cls="zero"), el("div", id="knob", cls="knob"),
                 id="track", cls="track", on=["pointerdown", "pointermove", "pointerup", "pointercancel"],
                 capture=True, focus=True),
              el("div", el("span", id="lblMax", text=f"+{umax:g}"), el("b", id="uVal", text="0.00"),
                 el("span", id="lblMin", text=f"−{umax:g}"), cls="labels"),
              cls="vs")


def stat(label, sid, initial="–"):
    return el("div", el("span", text=label), el("b", id=sid, text=initial), cls="stat")
