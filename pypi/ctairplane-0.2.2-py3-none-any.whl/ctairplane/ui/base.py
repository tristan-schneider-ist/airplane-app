"""Shared plumbing of the two widgets (replayed flight, manual flight): patches, events, frame loop."""

from __future__ import annotations

import time
from importlib import resources

from ctbridge import Canvas2D, FrameBuffer, el

from .scene import draw_scene

KEYS_PREVENT = ["Space", "ArrowUp", "ArrowDown"]


def load_css() -> str:
    return resources.files("ctairplane").joinpath("assets/game.css").read_text(encoding="utf-8")


def scene_block(*extra):
    """Canvas with an (initially hidden) overlay, plus optional extra panels beside it."""
    return el("div",
              el("div", el("canvas", id="scene", cls="scene"),
                 el("div", el("div", id="overlayBox", cls="box"), id="overlay", cls="overlay hidden"),
                 id="wrap", cls="canvaswrap", focus=True),
              *extra, cls="stage")


def header(task):
    return el("header",
              el("div", el("span", text="✈"), el("span", text=task.title), cls="title"),
              el("button", id="bFs", text="⛶ Vollbild", cls="fsbtn", on=["click"], attrs={"title": "Vollbild umschalten (F)"}))


def speed_select():
    opts = [el("option", text=f"{s:g}×", attrs={"value": str(s), **({"selected": ""} if s == 1 else {})}) for s in (0.5, 1, 2, 4)]
    return el("label", "Geschwindigkeit", el("select", *opts, id="speed", on=["change"]))


class BridgeApp:
    """Subclasses provide ``spec()``, ``handlers()``, ``advance(dt)``, ``update_stats(force)``, ``view`` and ``on_key``."""

    def __init__(self, task, send):
        self.task, self._send = task, send
        self.speed, self.fullscreen = 1.0, False
        self._patches, self._cache, self._last_stat = [], {}, 0.0
        self.last_frame_ms = 0.0
        self._handlers = {
            ("click", "bFs"): lambda m: self._send({"t": "fullscreen", "on": "toggle"}),
            ("change", "speed"): lambda m: setattr(self, "speed", float(m["value"])),
        }
        self._handlers.update(self.handlers())

    # ---- hooks
    def spec(self): raise NotImplementedError
    def handlers(self): return {}
    def advance(self, dt): pass
    def update_stats(self, force=False): pass
    def on_key(self, m): pass
    def after_ready(self): pass

    # ---- patches
    def patch(self, op, id, a=None, b=None):
        key = (op, id, a if op in ("cls", "attr", "style") else None)
        val = b if op in ("cls", "attr", "style") else a
        if op != "children" and self._cache.get(key) == val:
            return
        self._cache[key] = val
        self._patches.append([op, id, a, b] if b is not None else [op, id, a])

    def text(self, id, s):
        self.patch("text", id, s)

    def show(self, id, on=True):
        self.patch("cls", id, "hidden", not on)

    def throttled(self, force):
        now = time.monotonic()
        if not force and now - self._last_stat < 0.09:
            return False
        self._last_stat = now
        return True

    def set_overlay(self, *children):
        self.patch("children", "overlayBox", list(children))
        self.show("overlay", True)

    # ---- events
    def on_event(self, m):
        ev = m.get("ev")
        if ev == "tick":
            return self.on_tick(m)
        if ev == "ready":
            return self.on_ready()
        if ev == "key":
            return self.on_key(m)
        if ev == "fullscreen":
            self.fullscreen = bool(m["on"])
            self.patch("cls", "__root", "fs", self.fullscreen)
            self.text("bFs", "✕ Vollbild aus" if self.fullscreen else "⛶ Vollbild an")
            return
        h = self._handlers.get((ev, m.get("id")))
        if h:
            h(m)

    def on_ready(self):
        self._cache.clear()
        self._patches.clear()
        self._send({"t": "ui", "spec": self.spec(), "prevent": KEYS_PREVENT, "css": load_css()})
        self.after_ready()

    def on_tick(self, m):
        t0 = time.perf_counter()
        self.advance(min(0.1, max(0.0, m.get("dt", 0.0))))
        self.update_stats()
        buf, draw = FrameBuffer(), {}
        size = m.get("sizes", {}).get("scene")
        if size and size[0] > 0 and size[1] > 0:
            c = Canvas2D(buf)
            draw_scene(c, self.view, self.task, float(size[0]), float(size[1]))
            draw["scene"] = c.ops
        patches, self._patches = self._patches, []
        self.last_frame_ms = (time.perf_counter() - t0) * 1000
        self._send({"t": "frame", "patches": patches, "draw": draw}, buf.to_bytes())
