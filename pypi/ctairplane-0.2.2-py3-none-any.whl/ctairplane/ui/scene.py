"""Scene drawing (ported 1:1 from the original canvas code): sky, mountains, clouds, corridor, plane."""

from __future__ import annotations

import math
import random
import time

from ..core.sim import clamp
from .widgets import num

_rng = random.Random(7)
CLOUDS = [dict(x=_rng.random() * 3000, y=_rng.random(), s=0.6 + _rng.random() * 1.1, p=0.15 + _rng.random() * 0.25)
          for _ in range(14)]


def nice_step(rng: float) -> float:
    raw = rng / 6
    p = 10 ** math.floor(math.log10(raw))
    m = raw / p
    return (1 if m < 1.5 else 2 if m < 3.5 else 5 if m < 7.5 else 10) * p


def frange(a, b, st):
    """JS-style ``for (v = a; v <= b; v += st)`` (floating accumulation included)."""
    v = a
    while v <= b:
        yield v
        v += st


def draw_cloud(c, x, y, s):
    c.beginPath()
    c.arc(x, y, 16 * s, 0, 7)
    c.arc(x + 18 * s, y - 8 * s, 20 * s, 0, 7)
    c.arc(x + 40 * s, y, 16 * s, 0, 7)
    c.rect(x, y, 40 * s, 16 * s)
    c.fill()


def draw_plane(c, x, y, ang, color):
    c.save(); c.translate(x, y); c.rotate(ang); c.scale(0.95, 0.95)
    c.set("lineJoin", "round"); c.set("lineWidth", 1.6); c.set("strokeStyle", "#1c2333")

    def poly(pts, fill):
        c.set("fillStyle", fill); c.beginPath(); c.moveTo(*pts[0])
        for p in pts[1:]:
            c.lineTo(*p)
        c.closePath(); c.fill(); c.stroke()

    def ell(cx, cy, rx, ry, fill, end=7, stroke=True):
        c.set("fillStyle", fill); c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, end); c.fill()
        if stroke:
            c.stroke()

    poly([(-26, -3), (-40, -22), (-31, -22), (-15, -4)], color)             # tail fin
    poly([(4, 1), (-6, -7), (-16, -7), (-8, 1)], "#b7c3da")                  # far wing
    ell(0, 0, 37, 10, "#fff")                                                # body
    ell(0, 3, 30, 3, color, 3.1416, stroke=False)                            # stripe
    ell(18, -3, 8, 4.5, "#7fc4ff")                                           # cockpit
    poly([(8, 3), (-8, 3), (-22, 17), (-9, 17)], color)                      # near wing
    ell(-33, 0, 8, 2.4, "#b7c3da")                                           # tail stabiliser
    c.set("fillStyle", "#1c2333"); c.beginPath(); c.arc(38, 0, 2.6, 0, 7); c.fill()   # propeller hub
    c.set("fillStyle", "rgba(28,35,51,.28)"); c.beginPath()
    c.ellipse(40, 0, 3 + 2 * abs(math.sin(time.monotonic() * 1000 / 25)), 15, 0, 0, 7); c.fill()
    c.restore()


def arrow(c, x, y0, y1, color):
    if abs(y1 - y0) < 3:
        return
    d = (y1 > y0) - (y1 < y0)
    c.set("strokeStyle", color); c.set("fillStyle", color); c.set("lineWidth", 4); c.set("lineCap", "round")
    c.beginPath(); c.moveTo(x, y0); c.lineTo(x, y1 - d * 6); c.stroke()
    c.beginPath(); c.moveTo(x - 8, y1 - d * 10); c.lineTo(x + 8, y1 - d * 10); c.lineTo(x, y1); c.closePath(); c.fill()


class FlightCursor:
    """View of a recorded ``Flight`` at sample ``k`` (same attributes as a live ``ClosedLoop``)."""

    def __init__(self, flight, k=0):
        self.flight, self.k = flight, k
        self.Ts, self.Y = flight.Ts, flight.Y

    @property
    def t(self): return self.k * self.Ts
    @property
    def y(self): return self.Y[self.k]
    @property
    def u(self): return self.flight.U[self.k]
    @property
    def vy(self): return self.flight.VY[self.k]


def draw_scene(c, loop, task, W, H):
    """Draw the scene for ``loop`` = anything with t, k, Ts, Y, y, u, vy (a ClosedLoop or FlightCursor)."""
    t, tp, tf = loop.t, task.view_past, task.view_future
    ylo, yhi, tol, dur, umax = task.y_lim[0], task.y_lim[1], task.tol, task.duration, task.u_max
    pps = W / (tp + tf)
    px0 = tp * pps
    m = 34
    ypps = (H - 2 * m) / (yhi - ylo)
    tx = lambda tt: (tt - t) * pps + px0
    yy = lambda v: H - m - (v - ylo) * ypps
    r_at = task.r

    c.set("fillStyle", {"lin": [0, 0, 0, H, [[0, "#5fa8ec"], [0.7, "#bfe3fb"], [1, "#e9f6ff"]]]})
    c.fillRect(0, 0, W, H)

    for p, col, amp, base in ((0.05, "#a9c3df", 60, 0.78), (0.12, "#8eb0d2", 46, 0.88)):   # parallax mountains
        c.set("fillStyle", col); c.beginPath()
        pts = [0, H]
        for x in range(0, int(W) + 1, 8):
            w = x + t * pps * p
            pts += [x, H * base - amp * (0.5 + 0.28 * math.sin(w / 90) + 0.18 * math.sin(w / 37 + 1) + 0.1 * math.sin(w / 15))]
        pts += [W, H]
        c.path(pts, close=True); c.fill()

    c.set("fillStyle", "rgba(255,255,255,.85)")
    span = W + 300
    for cl in CLOUDS:
        draw_cloud(c, ((cl["x"] - t * pps * cl["p"]) % span) - 150, 20 + cl["y"] * (H - 140), cl["s"])

    st = nice_step(yhi - ylo)                                                            # altitude grid
    c.set("font", "11px ui-monospace,Menlo,monospace"); c.set("textBaseline", "middle"); c.set("lineWidth", 1)
    for v in frange(math.ceil(ylo / st) * st, yhi, st):
        y = yy(v)
        c.set("strokeStyle", "rgba(20,40,80,.12)"); c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke()
        c.set("fillStyle", "rgba(20,40,80,.55)"); c.fillText(num(v), 6, y - 7)

    c.set("textBaseline", "alphabetic"); c.set("textAlign", "center")                    # time ticks
    for s in range(math.ceil(max(0, t - tp)), int(math.floor(min(dur, t + tf))) + 1):
        x = tx(s)
        c.set("strokeStyle", "rgba(20,40,80,.1)"); c.beginPath(); c.moveTo(x, H - 16); c.lineTo(x, H); c.stroke()
        if s % 2 == 0:
            c.set("fillStyle", "rgba(20,40,80,.5)"); c.fillText(f"{s}s", x, H - 4)
    c.set("textAlign", "left")

    t0, t1, step = t - tp, min(t + tf, dur + 0.0001), 5 / pps                             # corridor
    a0 = max(0, t0)

    def corridor(a, b):
        pts = []
        for tt in frange(a, b + 1e-9, step):
            pts += [tx(tt), yy(r_at(tt) + tol)]
        pts += [tx(b), yy(r_at(b) + tol)]
        tt = b
        while tt >= a - 1e-9:
            pts += [tx(tt), yy(r_at(tt) - tol)]
            tt -= step
        pts += [tx(a), yy(r_at(a) - tol)]
        c.beginPath(); c.path(pts, close=True)

    if t1 > a0:
        c.save(); c.beginPath(); c.rect(px0, 0, W, H); c.clip(); corridor(max(a0, t), t1)
        c.set("fillStyle", "rgba(47,109,246,.22)"); c.fill()
        c.set("strokeStyle", "rgba(47,109,246,.7)"); c.set("lineWidth", 1.5); c.stroke(); c.restore()
        c.save(); c.beginPath(); c.rect(0, 0, px0, H); c.clip()
        if t > a0:
            corridor(a0, min(t, t1)); c.set("fillStyle", "rgba(47,109,246,.09)"); c.fill()
        c.restore()
        c.set("strokeStyle", "#1d4fd8"); c.set("lineWidth", 2); c.setLineDash([8, 7]); c.beginPath()
        c.path([v for tt in frange(a0, t1 + 1e-9, step) for v in (tx(tt), yy(r_at(tt)))])
        c.stroke(); c.setLineDash([])

    if dur - t < tf:                                                                      # finish line
        x, s = tx(dur), 10
        for i in range(int(H // s) + 1):
            c.set("fillStyle", "#111" if i % 2 else "#fff"); c.fillRect(x, i * s, 6, s)
            c.set("fillStyle", "#fff" if i % 2 else "#111"); c.fillRect(x + 6, i * s, 6, s)

    c.set("lineCap", "round"); c.set("lineWidth", 4)                                      # contrail (chunked)
    k_end = loop.k
    k_start = max(0, k_end - int(tp // loop.Ts))
    stride = max(1, int(0.02 // loop.Ts))
    ks = list(range(k_start, k_end + 1, stride))
    for i in range(0, len(ks) - 1, 6):
        chunk = ks[i:i + 7]
        pts = [v for k in chunk for v in (tx(k * loop.Ts), yy(loop.Y[k]))]
        xm = tx(chunk[len(chunk) // 2] * loop.Ts)
        c.set("strokeStyle", f"rgba(255,255,255,{0.15 + 0.7 * (xm / px0):.3f})")
        c.beginPath(); c.path(pts); c.stroke()

    r, y = r_at(t), loop.y                                                                # beacon + plane
    in_tube = abs(r - y) <= tol
    pulse = 1 + 0.12 * math.sin(time.monotonic() * 1000 / 180)
    c.set("strokeStyle", "#f59e0b"); c.set("lineWidth", 3); c.beginPath(); c.arc(px0, yy(r), 11 * pulse, 0, 7); c.stroke()
    c.set("fillStyle", "#f59e0b"); c.beginPath(); c.arc(px0, yy(r), 3.5, 0, 7); c.fill()

    py = clamp(yy(y), 14, H - 14)
    off = -1 if yy(y) < 14 else 1 if yy(y) > H - 14 else 0
    ang = clamp(-math.atan2(loop.vy * ypps, pps * 1.2), -0.7, 0.7)
    if off == 0:
        c.set("fillStyle", "rgba(20,164,111,.28)" if in_tube else "rgba(229,72,77,.28)")
        c.beginPath(); c.arc(px0, py, 34, 0, 7); c.fill()
        arrow(c, px0 + 3, py, py - (loop.u / umax) * 62, "#f59e0b")
        draw_plane(c, px0, py, ang, "#14a46f" if in_tube else "#e5484d")
    else:
        c.set("fillStyle", "#e5484d"); c.beginPath()
        c.moveTo(px0, py + off * 8); c.lineTo(px0 - 14, py - off * 8); c.lineTo(px0 + 14, py - off * 8); c.closePath(); c.fill()
        c.set("font", "bold 12px system-ui"); c.fillText(f"plane off screen: {y:.1f}", px0 + 20, py - off * 4)
