"""Manual flight: the one real-time mode. You steer with a throttle slider / keys; the kernel simulates live."""

from __future__ import annotations

from ctbridge import el

from ..core.controllers import Manual
from ..core.scoring import Best, stars
from ..core.sim import clamp
from .base import BridgeApp, header, scene_block, speed_select
from .widgets import fmt, stat, vslider

SLIDER_H = 250 - 2 - 30           # usable knob travel in px (track height minus border and knob)


class ManualApp(BridgeApp):
    """``on_finish(flight)`` is called when a flight ends (done or crashed)."""

    def __init__(self, task, send, on_finish=None, spring=False):
        self.loop = task.new_loop()
        self.manual = Manual(task.u_max)
        self.on_finish, self.spring, self.dragging = on_finish, spring, False
        self.state, self.acc, self.best, self.flight = "idle", 0.0, Best(), None
        super().__init__(task, send)

    @property
    def view(self):
        return self.loop

    # ---- layout
    def spec(self):
        t = self.task
        panel = el("aside", el("h3", text="Stellgröße u"), vslider(t.u_max),
                   el("label", el("input", id="spring", on=["change"], attrs={"type": "checkbox"}, checked=self.spring),
                      " Schieberegler nach Loslassen auf 0", cls="hint"),
                   el("div", "Schieberegler oder ", el("b", text="↑ ↓"), " Tasten benutzen (zuerst Spielfeld anklicken). ",
                      el("b", text="Leertaste"), " = Start / Pause.", cls="hint"),
                   id="panelManual", cls="panel")
        return el("div", header(t), scene_block(panel),
                  el("div",
                     el("button", id="bStart", text="▶ Start", cls="btn", on=["click"]),
                     el("button", id="bReset", text="↺ Neustart", cls="btn sec", on=["click"]),
                     speed_select(),
                     el("div", stat("Zeit", "sT", "0.0 s"), stat("Abweichung e", "sE", "0.00"),
                        stat("Durchschnittliche Abweichung", "sMeanE"), stat("Best", "sBest"), cls="stats"),
                     cls="bar"), cls="app")

    def handlers(self):
        h = {("click", "bStart"): lambda m: self.toggle_run(),
             ("click", "oGo"): lambda m: self.toggle_run(),
             ("click", "bReset"): lambda m: self.reset(),
             ("click", "oAgain"): lambda m: self.restart(),
             ("change", "spring"): lambda m: setattr(self, "spring", bool(m["checked"]))}
        for ev in ("pointerdown", "pointermove", "pointerup", "pointercancel"):
            h[(ev, "track")] = self._on_track
        return h

    def after_ready(self):
        self.reset()
        self.update_best()

    # ---- game flow
    def reset(self):
        self.loop.reset()
        self.manual.reset()
        self.acc, self.state = 0.0, "idle"
        self.update_knob()
        self.set_overlay(el("h2", text="Startklar?"),
                         el("p", "Regle das Flugzeug selbst mit dem Schieberegler.", el("br"),
                            "Bleibe möglichst nah an der Sollhöhe."),
                         el("button", id="oGo", text="▶ Start", cls="btn", on=["click"]))
        self.update_buttons()
        self.update_stats(True)

    def restart(self):
        self.reset()
        self.state = "running"
        self.show("overlay", False)
        self.update_buttons()

    def toggle_run(self):
        if self.state in ("idle", "paused"):
            self.state = "running"
            self.show("overlay", False)
        elif self.state == "running":
            self.state = "paused"
        else:
            return self.restart()
        self.update_buttons()

    def update_buttons(self):
        self.text("bStart", {"running": "⏸ Pause", "paused": "▶ Weiter", "idle": "▶ Start"}.get(self.state, "▶ Erneut fliegen"))

    def update_best(self):
        b = self.best.get("manual")
        self.text("sBest", "–" if b is None else f"{b} %")

    def advance(self, dt):
        if self.state != "running":
            return
        self.acc += dt * self.speed
        n = 0
        while self.acc >= self.loop.Ts and self.state == "running" and n < 2000:
            self.loop.step(self.manual)
            self.acc -= self.loop.Ts
            n += 1
            if self.loop.status != "running":
                self.state = self.loop.status
                self.finish()

    def finish(self):
        loop = self.loop
        crashed = loop.status == "crashed"
        self.flight = loop.flight()
        self.best.update("manual", loop.score, crashed)
        if crashed:
            self.set_overlay(el("h2", text="💥 Plane lost"), el("p", text=loop.message or "The closed loop diverged."),
                             el("button", id="oAgain", text="Try again", cls="btn", on=["click"]))
        else:
            s = stars(loop.score)
            self.set_overlay(el("h2", text="Flug abgeschlossen"),
                             el("div", "★" * s, el("span", text="★" * (3 - s), style={"opacity": ".3"}), cls="stars"),
                             el("p",
                                "Durchschnittliche Abweichung ", el("b", text=f"{loop.mean_error:.3f}")),
                             el("button", id="oAgain", text="Fly again", cls="btn", on=["click"]))
        self.update_buttons()
        self.update_stats(True)
        self.update_best()
        if self.on_finish:
            self.on_finish(self.flight)

    # ---- stats / input
    def update_knob(self):
        v = self.manual.slider
        self.patch("style", "knob", "top", f"{15 + (1 - (v + 1) / 2) * SLIDER_H:.1f}px")
        self.text("uVal", fmt(v * self.task.u_max))

    def update_stats(self, force=False):
        if not self.throttled(force):
            return
        loop = self.loop
        self.text("sT", f"{loop.t:.1f} s")
        self.text("sE", fmt(loop.R[loop.k] - loop.Y[loop.k]))
        self.text("sIn", f"{loop.score} %" if loop.k else "–")
        self.text("sRms", f"{loop.rms:.3f}" if loop.k else "–")
        self.text("sMeanE", f"{loop.mean_error:.3f}" if loop.k else "–")
        self.text("uVal", fmt(self.manual.slider * self.task.u_max))

    def _on_track(self, m):
        ev = m["ev"]
        if ev == "pointerdown":
            self.dragging = True
        if ev in ("pointerdown", "pointermove") and self.dragging:
            _, top, _, h = m["rect"]
            f = clamp((m["y"] - top - 15) / (h - 30), 0, 1)
            self.manual.slider = 0.0 if abs(1 - 2 * f) < 0.03 else 1 - 2 * f
            self.update_knob()
        elif ev in ("pointerup", "pointercancel"):
            self.dragging = False
            if self.spring:
                self.manual.slider = 0.0
                self.update_knob()

    def on_key(self, m):
        if m.get("inp"):
            return
        key, s = m["key"], self.manual
        if m["code"] == "Space":
            self.toggle_run()
        elif key in ("f", "F"):
            self._send({"t": "fullscreen", "on": "toggle"})
        elif key in ("ArrowUp", "w"):
            s.slider = clamp(s.slider + 0.1, -1, 1); self.update_knob()
        elif key in ("ArrowDown", "s"):
            s.slider = clamp(s.slider - 0.1, -1, 1); self.update_knob()
        elif key in ("0", "c"):
            s.slider = 0.0; self.update_knob()
