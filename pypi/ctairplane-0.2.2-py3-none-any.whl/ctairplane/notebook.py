"""Notebook-facing API: ``manual``, ``fly``, ``tune`` / ``tune_pid`` / ``tune_state_feedback``.

Every simulated mode shows the same three things: sliders (optional), the animated airplane
(``ui.player.Player``) and the matplotlib figure of the flight. ``manual`` is the one real-time widget.
"""

from __future__ import annotations

import math

import ipywidgets as w

from .core.controllers import PID, StateFeedback, UserController, auto_n
from .core.flight import Flight, simulate
from .plotting import figure_html, plot_flight


def _player(task, flight=None):
    from ctbridge import BridgeWidget
    from .ui.player import Player
    return BridgeWidget(lambda send: Player(task, send, flight))


def _wrap_user_controller(task, controller):
    return controller if isinstance(controller, UserController) else UserController(controller, task.Ts)


class FlightBox(w.VBox):
    """Layout: [controls] / animated plane / matplotlib figure. ``.flight`` is the last flight shown."""

    def __init__(self, task, controls=()):
        self.task, self.flight = task, None
        self.player, self.figure = _player(task), w.HTML()
        super().__init__([*controls, self.player, self.figure])

    def show_flight(self, flight: Flight):
        self.flight = flight
        self.figure.value = figure_html(plot_flight(flight, self.task))
        self.player.app.load(flight)


def fly(task, controller) -> FlightBox:
    """Simulate ``controller`` once (``fn(t, r, y, x) -> u``, any subset of the arguments; optional ``reset()``)."""
    box = FlightBox(task)
    box.show_flight(simulate(task, _wrap_user_controller(task, controller)))
    return box


class Tuner(FlightBox):
    """Sliders (and checkboxes) -> controller -> simulate -> figure + plane, on every change."""

    def __init__(self, task, make_controller, controls: dict, info=None):
        self.make_controller, self.controls, self.info = make_controller, controls, info
        self.label = w.HTML()
        super().__init__(task, [w.VBox(list(controls.values())), self.label])
        for c in controls.values():
            c.observe(self.update, "value")
        self.update()

    @property
    def values(self):
        return {k: c.value for k, c in self.controls.items()}

    def update(self, *_):
        ctrl = self.make_controller(**self.values)
        self.show_flight(simulate(self.task, ctrl))
        self.label.value = self.info(ctrl) if self.info else ""
        self.controller = ctrl


def _slider(desc, lo, hi, value, step=None):
    step = step or (hi - lo) / 400
    return w.FloatSlider(value=value, min=lo, max=hi, step=step, description=desc, continuous_update=False,
                         readout_format=".2f", style={"description_width": "40px"}, layout=w.Layout(width="480px"))


def tune(task, make_controller, params: dict, info=None) -> Tuner:
    """Generic tuner. ``params = {"name": (lo, hi, initial)}``; ``make_controller(**values)`` returns a controller."""
    wrapped = lambda **v: _wrap_user_controller(task, make_controller(**v))     # any subset of t, r, y, x
    return Tuner(task, wrapped, {k: _slider(k, *p) for k, p in params.items()}, info)


def tune_pid(task, kp=2.0, ki=0.0, kd=2.0, ranges=None) -> Tuner:
    """u = Kp·e + Ki·∫e + Kd·ė (filtered, anti-windup) with sliders for the three gains."""
    r = {"kp": (0, 20), "ki": (0, 10), "kd": (0, 10), **(ranges or {})}
    init = {"kp": kp, "ki": ki, "kd": kd}
    make = lambda kp, ki, kd: PID({"kp": kp, "ki": ki, "kd": kd}, task.Ts, task.u_max, task.derivative_filter)
    return Tuner(task, make, {k: _slider(k, *r[k], init[k]) for k in ("kp", "ki", "kd")})


def tune_state_feedback(task, K=None, N=None, k_range=20.0) -> Tuner:
    """u = −K·x + N·r with one slider per state and N (``N=None``: chosen for unit DC gain)."""
    n = task.order
    K = [0.0] * n if K is None else [float(k) for k in K]
    if len(K) != n:
        raise ValueError(f"K needs {n} entries (one per plant state)")
    controls = {f"K{i + 1}": _slider(f"K{i + 1}", -k_range, k_range, K[i], k_range / 200) for i in range(n)}
    controls["N"] = _slider("N", -50, 50, 1.0 if N is None else float(N), 0.05)
    controls["auto N"] = w.Checkbox(value=N is None, description="choose N for unit DC gain", indent=False)

    def make(**v):
        controls["N"].disabled = v["auto N"]
        return StateFeedback(task.ss, [v[f"K{i + 1}"] for i in range(n)], None if v["auto N"] else v["N"])

    def info(ctrl):
        nn, dc = auto_n(task.ss, ctrl.K)
        warn = "" if math.isfinite(dc) and abs(dc) > 1e-9 else " &nbsp; ⚠ no finite DC gain (unstable or integrator loop)"
        return f"<code>N = {ctrl.N:.3f}</code>{warn}" if ctrl.auto else warn

    return Tuner(task, make, controls, info)


class ManualBox(w.VBox):
    """Real-time manual flight + the matplotlib figure of the finished flight below it."""

    def __init__(self, task, spring=False):
        from ctbridge import BridgeWidget
        from .ui.manual import ManualApp
        self.task, self.figure = task, w.HTML()
        self.game = BridgeWidget(lambda send: ManualApp(task, send, self._finished, spring))
        super().__init__([self.game, self.figure])

    @property
    def flight(self):
        """The last finished flight (``None`` before the first one ends)."""
        return self.game.app.flight

    def _finished(self, flight: Flight):
        self.figure.value = figure_html(plot_flight(flight, self.task))


def manual(task, spring=False) -> ManualBox:
    """Fly by hand: throttle slider or ↑ ↓ keys. The result (score + figure) appears below the plane."""
    return ManualBox(task, spring)
