"""SISO plants for the airplane game, described with python-control (``ct.tf`` / ``ct.ss``).

The *output* ``y`` of the plant is the altitude of the airplane, the *input* ``u`` is what you (or your
controller) command.  A transfer function is converted to the *controllable canonical form*, so the
state is ``x = [y, y', ...]`` for ``num = 1`` (e.g. ``x = [y, y']`` for ``1/s²``).
"""

from __future__ import annotations

from typing import Sequence

import control as ct
import numpy as np

_SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def _poly_str(c: Sequence[float]) -> str:
    """Descending-power coefficients -> 's^2 + 3s + 2' (pretty, with superscripts)."""
    n = len(c) - 1
    terms = []
    for i, a in enumerate(c):
        p = n - i
        if a == 0:
            continue
        mag = abs(a)
        coef = "" if (mag == 1 and p > 0) else f"{mag:g}"
        s = "s" if p >= 1 else ""
        if p > 1:
            s += str(p).translate(_SUP)
        terms.append(("-" if a < 0 else "+", coef + s))
    if not terms:
        return "0"
    out = ("-" if terms[0][0] == "-" else "") + terms[0][1]
    for sign, body in terms[1:]:
        out += f" {sign} {body}"
    return out


def _siso(sys):
    if sys.ninputs != 1 or sys.noutputs != 1:
        raise ValueError("the plant must be SISO (one input u, one output y)")
    if sys.dt not in (0, None):
        raise ValueError("the plant must be continuous-time")


def to_state_space(sys) -> "ct.StateSpace":
    """``ct.tf`` -> controllable canonical form, ``ct.ss`` -> unchanged (after SISO / continuous checks)."""
    if isinstance(sys, ct.StateSpace):
        _siso(sys)
        return sys
    if not isinstance(sys, ct.TransferFunction):
        raise TypeError("plant must be a control.TransferFunction (ct.tf) or control.StateSpace (ct.ss)")
    _siso(sys)
    num = np.trim_zeros(np.atleast_1d(np.asarray(sys.num[0][0], float)), "f")
    den = np.trim_zeros(np.atleast_1d(np.asarray(sys.den[0][0], float)), "f")
    if num.size == 0:
        num = np.zeros(1)
    if den.size < 2:
        raise ValueError("plant needs at least one state (deg den >= 1)")
    if num.size > den.size:
        raise ValueError("improper transfer function (deg num > deg den)")
    a = den / den[0]                                           # 1, a1, ..., an
    n = a.size - 1
    b = np.concatenate([np.zeros(n + 1 - num.size), num / den[0]])    # b0..bn
    A = np.zeros((n, n))
    A[np.arange(n - 1), np.arange(1, n)] = 1.0
    A[n - 1] = [-a[n - j] for j in range(n)]                   # -an ... -a1
    B = np.zeros((n, 1))
    B[n - 1, 0] = 1.0
    C = np.array([[b[n - j] - a[n - j] * b[0] for j in range(n)]])
    return ct.ss(A, B, C, b[0])


def describe(sys) -> str:
    if isinstance(sys, ct.TransferFunction):
        return f"G(s) = ({_poly_str(sys.num[0][0])}) / ({_poly_str(sys.den[0][0])})"
    return f"state space, order {sys.nstates}"


def initial_state_for_output(ss, y0: float) -> np.ndarray:
    """Minimum-norm state with C x = y0 (so the plane starts on the reference)."""
    C = np.asarray(ss.C, float).ravel()
    cc = float(C @ C)
    return np.zeros(C.size) if cc == 0 else C * y0 / cc


def double_integrator(gain: float = 1.0):
    """y'' = gain * u   ->   G(s) = gain / s^2"""
    return ct.tf([gain], [1, 0, 0])
