"""Fixed-step closed-loop simulation of a SISO state-space plant.

The plant (a ``ct.StateSpace``) is discretised exactly with a zero-order hold on u (``ct.c2d``)."""

from __future__ import annotations

import math

import control as ct
import numpy as np

from .references import r_at


def clamp(v, lo, hi):
    return min(hi, max(lo, v))


class ClosedLoop:
    """Plant + reference + score bookkeeping. A controller is any ``fn(t, r, y, x) -> u``.

    ``step(controller)`` advances one sample ``Ts``; ``status`` is ``running | done | crashed``.
    """

    def __init__(self, ss, ref, ref_dt, Ts, duration, u_max, tol, x0):
        self.ss, self.ref, self.ref_dt = ss, ref, ref_dt
        self.Ts, self.duration, self.u_max, self.tol = Ts, duration, u_max, tol
        self.x0 = np.asarray(x0, float)
        self.N = int(math.ceil(duration / Ts))
        d = ct.c2d(ss, Ts, method="zoh")
        self.Ad, self.Bd = np.asarray(d.A, float), np.asarray(d.B, float).ravel()
        self.C, self.D = np.asarray(ss.C, float).ravel(), float(np.asarray(ss.D, float).ravel()[0])
        self.reset()

    # -- helpers ------------------------------------------------------------
    def r(self, t: float) -> float:
        return r_at(self.ref, self.ref_dt, t)

    def output(self, x, u) -> float:
        return float(self.C @ x) + self.D * u

    def reset(self):
        self.x = self.x0.copy()
        self.k, self.t, self.u, self.vy = 0, 0.0, 0.0, 0.0
        self.sum_sq, self.in_tube = 0.0, 0
        self.status, self.message = "running", ""
        self.Y = [0.0] * (self.N + 1)
        self.R = [0.0] * (self.N + 1)
        self.U = [0.0] * (self.N + 1)
        self.VY = [0.0] * (self.N + 1)          # smoothed climb rate (drives the plane's pitch)
        self.Y[0], self.R[0] = self.output(self.x, 0.0), self.r(0.0)

    @property
    def y(self) -> float:
        return self.Y[self.k]

    @property
    def score(self) -> int:
        return int(math.floor(100 * self.in_tube / max(1, self.k) + 0.5))  # like JS Math.round

    @property
    def rms(self) -> float:
        return math.sqrt(self.sum_sq / max(1, self.k))

    # -- dynamics -----------------------------------------------------------
    def step(self, controller):
        """One sample. ``controller(t, r, y, x)`` returns the (already saturated or not) input u."""
        if self.status != "running":
            return
        k, Ts = self.k, self.Ts
        t = k * Ts
        y, r = self.output(self.x, self.u), self.r(t)
        try:
            u = float(controller(t, r, y, self.x.copy()))
        except Exception as e:  # user code: report it, keep the flight up to here
            self.status = "crashed"
            self.message = f"{type(e).__name__}: {e} (at t = {t:.2f} s)"
            return
        u = clamp(u if math.isfinite(u) else 0.0, -self.u_max, self.u_max)
        self.u = u
        x = self.x = self.Ad @ self.x + self.Bd * u
        self.k = k + 1
        self.t = self.k * Ts
        y2, r2 = self.output(x, u), self.r(self.t)
        self.Y[self.k], self.R[self.k], self.U[self.k] = y2, r2, u
        e2 = r2 - y2
        self.sum_sq += e2 * e2
        if abs(e2) <= self.tol:
            self.in_tube += 1
        kb = max(0, self.k - 6)
        self.vy = 0.8 * self.vy + 0.2 * (self.Y[self.k] - self.Y[kb]) / ((self.k - kb) * Ts)
        self.VY[self.k] = self.vy
        if not (math.isfinite(y2) and np.all(np.isfinite(x))) or abs(y2) > 1e7:
            self.status, self.message = "crashed", "The closed loop diverged – the altitude exploded. Try other inputs or gains."
        elif self.k >= self.N:
            self.status = "done"

    def flight(self):
        """Snapshot of everything recorded so far as an immutable-ish ``Flight``."""
        from .flight import Flight
        n = self.k + 1
        return Flight(self.Ts, self.R[:n], self.Y[:n], self.U[:n], self.VY[:n], self.status, self.message,
                      self.tol, self.u_max, self.duration)
