"""Score, stars and per-mode best score."""

from __future__ import annotations


def stars(score: int) -> int:
    return 3 if score >= 90 else 2 if score >= 70 else 1 if score >= 40 else 0


class Best:
    def __init__(self):
        self.values = {}

    def update(self, mode: str, score: int, crashed: bool = False):
        if not crashed and (mode not in self.values or score > self.values[mode]):
            self.values[mode] = score

    def get(self, mode: str):
        return self.values.get(mode)
