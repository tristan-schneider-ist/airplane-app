"""A recorded flight (simulated or flown by hand) and the batch ``simulate``."""

from __future__ import annotations

import math

from .scoring import stars as _stars


class Flight:
    """Sampled history of one flight: ``t[k] = k*Ts`` with reference R, output Y, input U (and climb rate VY)."""

    def __init__(self, Ts, R, Y, U, VY, status, message, tol, u_max, duration):
        self.Ts, self.R, self.Y, self.U, self.VY = Ts, list(R), list(Y), list(U), list(VY)
        self.status, self.message, self.tol, self.u_max, self.duration = status, message, tol, u_max, duration
        self.IN, self.SS = [0], [0.0]            # prefix counts (samples inside the corridor, squared error)
        for k in range(1, len(self.Y)):
            e = self.R[k] - self.Y[k]
            self.IN.append(self.IN[-1] + (abs(e) <= tol))
            self.SS.append(self.SS[-1] + e * e)

    @property
    def n(self) -> int:
        """Index of the last sample."""
        return len(self.Y) - 1

    @property
    def t(self):
        return [k * self.Ts for k in range(len(self.Y))]

    def score_at(self, k: int) -> int:
        return int(math.floor(100 * self.IN[k] / max(1, k) + 0.5))

    def rms_at(self, k: int) -> float:
        return math.sqrt(self.SS[k] / max(1, k))

    def mean_error_at(self, k: int) -> float:
        return sum((abs(self.R[i] - self.Y[i]) for i in range(k))) / max(1, k)

    @property
    def score(self) -> int:
        """Percentage of the flight spent inside the corridor r(t) ± tol."""
        return self.score_at(self.n)

    @property
    def rms(self) -> float:
        return self.rms_at(self.n)

    @property
    def mean_error(self) -> float:
        return self.mean_error_at(self.n)

    @property
    def stars(self) -> int:
        return _stars(self.score)

    @property
    def crashed(self) -> bool:
        return self.status == "crashed"

    def summary(self, emoji=True) -> str:
        """One line for humans; ``emoji=False`` sticks to glyphs that matplotlib's default font has."""
        if self.crashed:
            return f"{'💥' if emoji else '✗'} Plane lost – {self.message}"
        #return f"{'★' * self.stars}{'☆' * (3 - self.stars)}  {self.score} % of the flight inside the corridor · RMS error {self.rms:.3f}"
        return f"Durchschnittliche Abweichung von der Referenz: {self.mean_error:.3f} m"

    def plot(self, task):
        from ..plotting import plot_flight
        return plot_flight(self, task)

    def __repr__(self):
        return f"Flight({self.status}, score={self.score} %, rms={self.rms:.3f}, {self.n} samples)"


def simulate(task, controller) -> Flight:
    """Fly ``controller`` (``fn(t, r, y, x) -> u``, optional ``reset()``) through ``task`` and record the flight."""
    loop = task.new_loop()
    if hasattr(controller, "reset"):
        controller.reset()
    while loop.status == "running":
        loop.step(controller)
    return loop.flight()
