"""Small helpers that build reference trajectories r(t) (plain Python callables)."""

from __future__ import annotations

import math


def constant(value: float):
    return lambda t: value


def step(before: float, after: float, t_step: float):
    return lambda t: after if t >= t_step else before


def steps(points):
    """Piecewise constant: ``steps([(0, 0), (5, 3), (12, -2)])`` holds each value from its time on."""
    pts = sorted(points)

    def r(t):
        v = pts[0][1]
        for tk, vk in pts:
            if t >= tk:
                v = vk
        return v

    return r


def waypoints(points):
    """Piecewise linear through ``[(t0, y0), (t1, y1), ...]`` (held constant outside)."""
    pts = sorted(points)

    def r(t):
        if t <= pts[0][0]:
            return pts[0][1]
        for (t0, y0), (t1, y1) in zip(pts, pts[1:]):
            if t <= t1:
                return y0 + (y1 - y0) * (t - t0) / (t1 - t0)
        return pts[-1][1]

    return r


def sine(offset: float = 0.0, amplitude: float = 1.0, freq_hz: float = 0.1, phase: float = 0.0):
    w = 2 * math.pi * freq_hz
    return lambda t: offset + amplitude * math.sin(w * t + phase)


def sample(fn, ref_dt: float, t_end: float):
    """Sample r(t) on a regular grid (checks that it is finite)."""
    n = int(math.ceil(t_end / ref_dt)) + 1
    out = []
    for i in range(n):
        v = float(fn(i * ref_dt))
        if not math.isfinite(v):
            raise ValueError(f"reference({i * ref_dt:g}) is not finite")
        out.append(v)
    return out


def r_at(ref, ref_dt: float, t: float) -> float:
    """Linear interpolation into a sampled reference (held constant after the last sample)."""
    x = max(0.0, t) / ref_dt
    i = int(x)
    if i >= len(ref) - 1:
        return ref[-1]
    return ref[i] + (ref[i + 1] - ref[i]) * (x - i)
