"""Controllers: manual input, PID, state feedback and the user's own Python controller.

Every controller is a callable ``(t, r, y, x) -> u``; ``reset()`` clears its memory.
"""

from __future__ import annotations

import inspect
import math
import warnings

import control as ct
import numpy as np

from .sim import clamp


def _sign(v: float) -> int:
    return (v > 0) - (v < 0)


class Manual:
    """u = slider * u_max, the slider position is set by the UI."""

    def __init__(self, u_max):
        self.u_max, self.slider = u_max, 0.0

    def reset(self):
        self.slider = 0.0

    def __call__(self, t, r, y, x):
        return self.slider * self.u_max


class PID:
    """u = Kp e + Ki ∫e + Kd de/dt (filtered), clamping anti-windup. ``K`` may be edited live."""

    def __init__(self, K, Ts, u_max, derivative_filter=50.0):
        self.K, self.Ts, self.u_max, self.derivative_filter = dict(K), Ts, u_max, derivative_filter
        self.u = 0.0
        self.reset()

    def reset(self):
        self.I = self.e_prev = self.dF = 0.0
        self.first = True
        self.P = self.Ic = self.Dc = 0.0

    def __call__(self, t, r, y, x):
        K, Ts = self.K, self.Ts
        e = r - y
        tau = 1.0 / self.derivative_filter
        if self.first:
            self.e_prev, self.first = e, False
        self.dF = (tau * self.dF + (e - self.e_prev)) / (tau + Ts)
        self.e_prev = e
        P, Dd = K["kp"] * e, K["kd"] * self.dF
        u_unsat = P + K["ki"] * self.I + Dd
        u = clamp(u_unsat, -self.u_max, self.u_max)
        if u == u_unsat or _sign(e) != _sign(u_unsat):
            self.I += e * Ts
        self.P, self.Ic, self.Dc, self.u = P, K["ki"] * self.I, Dd, u
        return u


def auto_n(ss, K):
    """(N, dc): N = 1/dc for unit DC gain of the loop (A-BK, B, C-DK, D), or (nan, dc) if dc is not finite/non-zero."""
    A, B = np.asarray(ss.A, float), np.asarray(ss.B, float).reshape(-1, 1)
    C, D = np.asarray(ss.C, float).reshape(1, -1), np.asarray(ss.D, float).reshape(1, 1)
    K = np.asarray(K, float).reshape(1, -1)
    try:
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore")
            dc = float(np.real(np.asarray(ct.dcgain(ct.ss(A - B @ K, B, C - D @ K, D))).ravel()[0]))
    except Exception:       # singular A - BK (e.g. an integrator without feedback)
        dc = math.nan
    ok = math.isfinite(dc) and abs(dc) > 1e-9
    return (1.0 / dc if ok else math.nan), dc


class StateFeedback:
    """u = -K x + N r. ``auto`` chooses N for unit DC gain (recomputed only when K changes, not on every step)."""

    def __init__(self, ss, K, N=None):
        self.ss, self.K = ss, [float(k) for k in K]
        self.auto = N is None
        self.N = 1.0 if N is None else float(N)
        self.u, self._n_key = 0.0, None

    def reset(self):
        pass

    def refresh_n(self):
        if self.auto:
            key = tuple(self.K)
            if key != self._n_key:                       # auto_n costs ~0.15 ms: only when K changed
                n, _ = auto_n(self.ss, self.K)
                self.N, self._n_key = (n if math.isfinite(n) else 0.0), key

    def __call__(self, t, r, y, x):
        self.refresh_n()
        u = self.N * r - float(np.dot(self.K, x))
        self.u = u
        return u


class UserController:
    """Wraps the user's ``controller(...)``: any subset of the arguments t, r, y, x, dt, Ts."""

    ALLOWED = {"t", "r", "y", "x", "dt", "Ts"}

    def __init__(self, fn, Ts):
        names = list(inspect.signature(fn).parameters)
        if not names or not set(names) <= self.ALLOWED:
            raise TypeError(f"controller arguments must be chosen from {sorted(self.ALLOWED)}, got {names}")
        self.fn, self.names, self.Ts = fn, names, Ts

    def reset(self):
        if hasattr(self.fn, "reset"):
            self.fn.reset()

    def __call__(self, t, r, y, x):
        args = {"t": t, "r": r, "y": y, "x": x, "dt": self.Ts, "Ts": self.Ts}
        return self.fn(**{a: args[a] for a in self.names})
