"""What is flown: plant, reference, limits and view settings (shared by all modes)."""

from __future__ import annotations

import math

import numpy as np

from .plants import describe, initial_state_for_output, to_state_space
from .references import r_at, sample
from .sim import ClosedLoop


class Task:
    """The airplane task.

    Parameters
    ----------
    plant : control.TransferFunction | control.StateSpace
        SISO continuous-time plant. Input u = what you command, output y = altitude of the plane.
    reference : callable | float
        r(t): the altitude the plane should follow (seconds -> altitude).
    duration : float
        Length of one flight in seconds.
    u_max : float
        Input saturation |u| <= u_max (slider range and controller output limit).
    tol : float
        Half-width of the flight corridor; time inside it counts for the score.
    x0 : list | None
        Initial plant state. ``None`` -> start with y(0) = r(0).
    Ts : float
        Sample time of the simulation / controllers.
    y_lim : (float, float) | None
        Visible altitude range. ``None`` -> chosen automatically from the reference.
    """

    def __init__(self, plant, reference, duration=30.0, u_max=5.0, tol=0.5, x0=None, Ts=0.01, y_lim=None,
                 title="Regelungstechnik-Pilot", view_past=3.0, view_future=9.0, derivative_filter=50.0, ref_dt=0.02):
        if duration <= 0 or u_max <= 0 or tol <= 0 or Ts <= 0:
            raise ValueError("duration, u_max, tol and Ts must be positive")
        self.plant, self.ss = plant, to_state_space(plant)      # validates: SISO, continuous-time, proper
        self.duration, self.u_max, self.tol, self.Ts = float(duration), float(u_max), float(tol), float(Ts)
        self.title, self.view_past, self.view_future = title, float(view_past), float(view_future)
        self.derivative_filter, self.ref_dt = float(derivative_filter), float(ref_dt)
        self.reference = reference if callable(reference) else (lambda t, v=float(reference): v)
        self.ref = sample(self.reference, self.ref_dt, self.duration + self.view_future + 1.0)
        n = self.ss.nstates
        if x0 is None:
            self.x0 = initial_state_for_output(self.ss, self.ref[0])
        else:
            self.x0 = np.asarray(x0, float)
            if self.x0.shape != (n,):
                raise ValueError(f"x0 must have {n} entries")
        if y_lim is None:
            lo, hi = min(self.ref), max(self.ref)
            span = max(hi - lo, 4 * self.tol, 1e-9)
            pad = 0.55 * span
            self.y_lim = (lo - pad, hi + pad)
        else:
            self.y_lim = tuple(map(float, y_lim))
        self.plant_text = describe(plant)

    @property
    def order(self) -> int:
        return self.ss.nstates

    def r(self, t: float) -> float:
        return r_at(self.ref, self.ref_dt, t)

    def new_loop(self) -> ClosedLoop:
        return ClosedLoop(self.ss, self.ref, self.ref_dt, self.Ts, self.duration, self.u_max, self.tol, self.x0)
